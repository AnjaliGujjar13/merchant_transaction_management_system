# merchant_tran_mgmt_app/apps.py
from django.apps import AppConfig

class MerchantTranMgmtAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'merchant_tran_mgmt_app'  
